package kr.or.ddit.member.service;

import static org.junit.Assert.*;

import javax.inject.Inject;

import org.junit.Test;

import kr.or.ddit.AbstractTestCase;

//Mock request

public class MemberServiceImplTest extends AbstractTestCase{
	
	@Inject
	private MemberService service;

	@Test
	public void testInit() {
	}

	@Test
	public void testCreateMember() {
	}

	@Test
	public void testRetrieveMemberList() {
	}

	@Test
	public void testRetrieveMember() {
	}

	@Test
	public void testModifyMember() {
	}

	@Test
	public void testRemoveMember() {
	}

}
